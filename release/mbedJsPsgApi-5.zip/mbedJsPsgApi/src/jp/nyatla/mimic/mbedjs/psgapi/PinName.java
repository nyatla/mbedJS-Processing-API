package jp.nyatla.mimic.mbedjs.psgapi;

/**
 * This class defines PinName constant.
 */
public class PinName extends jp.nyatla.mimic.mbedjs.javaapi.PinName
{
}